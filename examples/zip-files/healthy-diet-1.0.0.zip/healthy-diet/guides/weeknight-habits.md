# Weeknight habits

1. Keep frozen vegetables and a grain (rice, quinoa) ready for busy nights.
2. Cook protein once, use twice (e.g. roast chicken → next-day salad).
3. Put fruit where you see it; hide ultra-processed snacks one shelf farther back.
4. Drink water with meals before reaching for sweet drinks.
5. Stop eating when comfortably satisfied — not stuffed.

Small repeats beat perfect plans you abandon.
