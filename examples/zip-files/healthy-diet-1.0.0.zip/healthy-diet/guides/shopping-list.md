# A starter shopping list

## Produce
- Leafy greens, broccoli or peppers
- Bananas or apples
- Lemons

## Pantry
- Oats or brown rice
- Canned beans or lentils
- Olive oil, vinegar, spices you already like

## Protein / dairy (as you prefer)
- Eggs or tofu
- Plain yogurt
- Canned tuna or other fish

Buy what you will actually cook this week — not an aspirational cart.
