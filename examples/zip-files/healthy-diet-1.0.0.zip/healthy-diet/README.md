# Healthy Diet

A small Nest knowledge pack for demos and local import testing.

## What's inside

- **concepts/** — core ideas (balance, nutrients, hydration)
- **guides/** — everyday habits you can try this week

Import this zip from the Hub panel (**Import**). Nest expects `pack.json` plus at least one Markdown file.
