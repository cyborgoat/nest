# Key nutrients to watch

| Focus | Why it matters | Common sources |
|-------|----------------|----------------|
| Fiber | Digestion, satiety | Vegetables, legumes, oats, berries |
| Protein | Muscle repair, fullness | Lentils, yogurt, eggs, fish |
| Unsaturated fats | Heart health | Olive oil, nuts, seeds, avocado |
| Water | Energy, concentration | Water, herbal tea, watery produce |

Prefer food sources first; supplements only when a clinician recommends them.
