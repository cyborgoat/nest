# The balance plate

A simple plate model:

- **Half** vegetables and fruit (variety of colors)
- **About a quarter** whole grains or starchy vegetables
- **About a quarter** protein (beans, fish, eggs, lean meat, tofu)
- Add a little healthy fat (olive oil, nuts, avocado) as needed

Use this as a default template, not a strict rule for every meal.
